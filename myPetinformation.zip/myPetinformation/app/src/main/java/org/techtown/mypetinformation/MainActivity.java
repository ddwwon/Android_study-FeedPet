package org.techtown.mypetinformation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.InitialIzeView();
    }

    Button cla_btn;
    TextView feed_amount;

    public void InitialIzeView(){
        cla_btn = (Button)findViewById(R.id.button);
        feed_amount = (TextView)findViewById(R.id.textView5);
    }

    public void onBtnCal(View view){
        double age = 2.0;
        double weight = 2.1;
        double result = 0.0;

        if(age <= 1){
            result = weight * 0.05;
        }
        else {
            result = weight * 0.02;
        }
        feed_amount.setText(String.valueOf(result));
    }
}